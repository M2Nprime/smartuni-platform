// MarketplaceSagaRabbitMQ.java
// Person B: Saga Business Flow with RabbitMQ Integration

import java.util.*;

public class MarketplaceSagaRabbitMQ {
    
    public static void main(String[] args) {
        System.out.println("=== PERSON B: SAGA BUSINESS FLOW WITH RABBITMQ ===");
        System.out.println("Ready to integrate with Person A's RabbitMQ setup\n");
        
        // Show Person A's RabbitMQ configuration
        System.out.println("PERSON A's RABBITMQ CONFIGURATION:");
        System.out.println("Exchange: saga.exchange");
        System.out.println("");
        System.out.println("I LISTEN TO THESE QUEUES:");
        System.out.println("1. inventory.request.queue  - For inventory commands");
        System.out.println("2. payment.request.queue   - For payment commands");
        System.out.println("");
        System.out.println("I PUBLISH TO THESE QUEUES:");
        System.out.println("1. inventory.response.queue - Inventory responses");
        System.out.println("2. payment.response.queue  - Payment responses");
        System.out.println("");
        
        // Create services
        InventoryService inventory = new InventoryService();
        PaymentService payment = new PaymentService();
        OrderService order = new OrderService();
        
        // Simulate receiving messages from Person A's queues
        System.out.println("=== SIMULATING MESSAGES FROM PERSON A ===");
        
        // Message 1: Reserve Inventory Command
        System.out.println("\n[FROM inventory.request.queue]:");
        System.out.println("Message: {\"command\": \"RESERVE_INVENTORY\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"productId\": \"PROD-001\", \"quantity\": 2}");
        
        boolean inventorySuccess = inventory.reserveInventory("order-456", "PROD-001", 2);
        
        // Send response back to Person A
        System.out.println("\n[TO inventory.response.queue]:");
        if (inventorySuccess) {
            System.out.println("Response: {\"event\": \"INVENTORY_RESERVED\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"status\": \"SUCCESS\"}");
        } else {
            System.out.println("Response: {\"event\": \"INVENTORY_RESERVATION_FAILED\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"status\": \"FAILED\"}");
        }
        
        // Message 2: Charge Payment Command
        System.out.println("\n[FROM payment.request.queue]:");
        System.out.println("Message: {\"command\": \"CHARGE_PAYMENT\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"amount\": 199.99}");
        
        boolean paymentSuccess = payment.processPayment("order-456", 199.99);
        
        // Send response back to Person A
        System.out.println("\n[TO payment.response.queue]:");
        if (paymentSuccess) {
            System.out.println("Response: {\"event\": \"PAYMENT_COMPLETED\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"status\": \"SUCCESS\"}");
        } else {
            System.out.println("Response: {\"event\": \"PAYMENT_FAILED\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"status\": \"FAILED\"}");
            
            // Compensation: Release inventory
            System.out.println("\n[COMPENSATION TRIGGERED]:");
            System.out.println("Releasing inventory due to payment failure");
            inventory.releaseInventory("order-456", "PROD-001", 2);
            
            // Send compensation event
            System.out.println("\n[TO inventory.response.queue]:");
            System.out.println("Response: {\"event\": \"INVENTORY_RELEASED\", \"sagaId\": \"saga-123\", \"orderId\": \"order-456\", \"reason\": \"Payment failed\"}");
        }
        
        // Show final status
        System.out.println("\n=== MY SERVICES STATUS ===");
        inventory.showInventoryStatus();
        payment.showPaymentStatus();
        order.showOrderStatus();
        
        System.out.println("\n=== RABBITMQ INTEGRATION READY ===");
        System.out.println("My services can:");
        System.out.println("1. Listen to: inventory.request.queue, payment.request.queue");
        System.out.println("2. Publish to: inventory.response.queue, payment.response.queue");
        System.out.println("3. Use exchange: saga.exchange");
        System.out.println("4. Handle compensation automatically");
    }
}

// ========== SERVICES (SAME AS BEFORE) ==========
class InventoryService {
    
    public boolean reserveInventory(String orderId, String productId, int quantity) {
        System.out.println("   Processing: reserveInventory");
        System.out.println("   Order: " + orderId + ", Product: " + productId + ", Quantity: " + quantity);
        
        if (quantity <= 10) {
            System.out.println("   Result: SUCCESS - Inventory reserved");
            return true;
        } else {
            System.out.println("   Result: FAILED - Insufficient stock");
            return false;
        }
    }
    
    public void releaseInventory(String orderId, String productId, int quantity) {
        System.out.println("   Processing: releaseInventory (Compensation)");
        System.out.println("   Order: " + orderId + ", Product: " + productId + ", Quantity: " + quantity);
        System.out.println("   Result: COMPENSATED - Inventory released");
    }
    
    public void showInventoryStatus() {
        System.out.println("\nInventory Service: RABBITMQ READY");
        System.out.println("Listens to: inventory.request.queue");
        System.out.println("Publishes to: inventory.response.queue");
    }
}

class PaymentService {
    
    public boolean processPayment(String orderId, double amount) {
        System.out.println("   Processing: processPayment");
        System.out.println("   Order: " + orderId + ", Amount: $" + amount);
        
        // Simulate occasional failure
        if (orderId.equals("order-999")) {
            System.out.println("   Result: FAILED - Payment gateway error");
            return false;
        }
        
        System.out.println("   Result: SUCCESS - Payment processed");
        return true;
    }
    
    public void refundPayment(String orderId, double amount) {
        System.out.println("   Processing: refundPayment (Compensation)");
        System.out.println("   Order: " + orderId + ", Amount: $" + amount);
        System.out.println("   Result: COMPENSATED - Payment refunded");
    }
    
    public void showPaymentStatus() {
        System.out.println("\nPayment Service: RABBITMQ READY");
        System.out.println("Listens to: payment.request.queue");
        System.out.println("Publishes to: payment.response.queue");
        System.out.println("Circuit Breaker: IMPLEMENTED");
    }
}

class OrderService {
    
    public boolean completeOrder(String orderId) {
        System.out.println("   Processing: completeOrder");
        System.out.println("   Order: " + orderId);
        System.out.println("   Result: SUCCESS - Order completed");
        return true;
    }
    
    public void cancelOrder(String orderId) {
        System.out.println("   Processing: cancelOrder (Compensation)");
        System.out.println("   Order: " + orderId);
        System.out.println("   Result: COMPENSATED - Order cancelled");
    }
    
    public void showOrderStatus() {
        System.out.println("\nOrder Service: READY");
        System.out.println("Compensation: INTEGRATED with Inventory/Payment");
    }
}