-- TABLES NEEDED FOR MY SERVICES:

-- 1. Products table
CREATE TABLE products (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100),
    stock INT,
    price DECIMAL(10,2)
);

-- 2. Inventory reservations
CREATE TABLE inventory_reservations (
    id VARCHAR(50) PRIMARY KEY,
    order_id VARCHAR(50),
    product_id VARCHAR(50),
    quantity INT,
    status VARCHAR(20)
);

-- 3. Payments table
CREATE TABLE payments (
    id VARCHAR(50) PRIMARY KEY,
    order_id VARCHAR(50),
    amount DECIMAL(10,2),
    status VARCHAR(20)
);

-- 4. Orders table
CREATE TABLE orders (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50),
    status VARCHAR(20),
    total_amount DECIMAL(10,2)
);